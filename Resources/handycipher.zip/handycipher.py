# -*- coding: latin-1 -*-
#
# Extended HandyCipher from Bruce Kallick
# according to http://eprint.iacr.org/2014/257.pdf, version 4.9
#
#  v2.7 (2015-03-18) Program for encryption and decryption created for MTC3 by AK-BE
#  This Python 3 source code is open source (it was tested with Python 3.4).

import sys
import os
import re
import random
import argparse

version = "v2.7 (2015-03-18)"

################################################################################

class ExtendedHandycipher:

	charmap = [["^","SPACE"],["0","ZERO"],["1","ONE"],["2","TWO"],["3","THREE"],["4","FOUR"],["5","FIVE"],["6","SIX"],["7","SEVEN"],["8","EIGHT"],["9","NINE"]]

	def __init__(self,key):
		self.corecipher = Corecipher(key)


	def info(self):
		try:
			print("Method: Extended Handycipher\n")
			print("Master key:  " + self.corecipher.key)
			print("Subkey:      " + self.corecipher.keyWithoutNumbers + "\n")
			print("Key matrix:\n" + self.corecipher.matrixstring)
			print("Forbidden bigrams: " + ' '.join(self.corecipher.bigrams) + "\n")
			print("")
		except:
			pass

		try:
			print("Session key: " + self.sessionHandycipher.corecipher.key)
			print("Subkey:      " + self.sessionHandycipher.corecipher.keyWithoutNumbers + "\n")
			print("Key matrix:\n" + self.sessionHandycipher.corecipher.matrixstring)
			print("Forbidden bigrams: " + ' '.join(self.sessionHandycipher.corecipher.bigrams) + "\n")
			print("")
		except:
			pass

		try:
			print("Encrypted session key: " + self.encryptedSessionKey)
			print("Hexdump: " + (' '.join(format(ord(x), '02x') for x in self.encryptedSessionKey)))
			print("Position in ciphertext: " + str(self.pos))
			print("Length: " + str(len(self.encryptedSessionKey)) + " characters")
			print("")
			print("Decrypted session key (expanded): " + self.expandedSessionKey)
			print("Decrypted session key (reduced):  " + self.reducedSessionKey)
			print("")
		except:
			pass


	def getxy(self):
		x = sum([self.corecipher.char2number[c] for c in "ABC"]) % 31
		y = sum([self.corecipher.char2number[c] for c in "DEF"]) % 31
		return (x, y)


	def getPos(self,text):
		x, y = self.getxy()
		return ((len(text)-500) // 31) * x + y


	def decode( self, ciphertext, verbose=0 ):

		self.pos = self.getPos(ciphertext)

		sessionKey, offset = self.corecipher.decode( ciphertext[self.pos:], 0, 41+56-1 )
		while ciphertext[self.pos+offset] not in self.corecipher.nulls: offset += 1
		offset += 1
		self.encryptedSessionKey = ciphertext[self.pos:self.pos+offset]
		ciphertext = ciphertext[:self.pos] + ciphertext[self.pos+offset:]

		self.expandedSessionKey, offset = self.corecipher.decode( self.encryptedSessionKey, 0 )
		self.reducedSessionKey = ExtendedHandycipher.reduceKey(self.expandedSessionKey)

		try:
			self.sessionHandycipher = Handycipher(self.reducedSessionKey)
		except Exception as e:
			#errmsg  = "Given session key:  '" + self.reducedSessionKey + "'\n"
			#errmsg += "Sorted session key: '" + Corecipher.sortstring(self.reducedSessionKey) + "'\n"
			#errmsg += "Regular sorted key: '" + Corecipher.sortstring(Corecipher.ciphertextalphabet) + "'"
			raise Exception("The embedded session key is not valid!\n\n" + e.args[0])

		return self.sessionHandycipher.decode( ciphertext, verbose )


	def encode( self, plaintext, verbose=0 ):

		# create session key that is encryptable with the master key and that can encrypt the plaintext
		maxtries = 100
		i = 0
		while i<maxtries:
			sessionKey = Corecipher.randomKey(plaintext)
			self.sessionHandycipher = Handycipher(sessionKey)
			self.reducedSessionKey = sessionKey
			self.expandedSessionKey = ExtendedHandycipher.expandKey(sessionKey)
			if self.corecipher.isEncryptable(self.expandedSessionKey): break
			i += 1

		if i>=maxtries:
			raise Exception("Could not create a session key for Extended Handycipher.")

		ciphertext = self.sessionHandycipher.encode( plaintext, verbose )

		handycipher = Handycipher( self.corecipher.key )
		ngrams = handycipher.corecipher.encodeNgrams( self.expandedSessionKey, 0 )
		self.encryptedSessionKey = handycipher.insertNulls( ''.join(ngrams[0:-1]) ) + ngrams[-1] + random.choice(handycipher.corecipher.nulls)

		self.pos = self.getPos(ciphertext+self.encryptedSessionKey)
		ciphertext = ciphertext[:self.pos] + self.encryptedSessionKey + ciphertext[self.pos:]

		return ciphertext


	@staticmethod
	def reduceKey(key):
		for (c,s) in ExtendedHandycipher.charmap:
			key = key.replace("^"+s+"^",c)
		return key


	@staticmethod
	def expandKey(key):
		for (c,s) in ExtendedHandycipher.charmap:
			key = key.replace(c,"^"+s+"^")
		return key

################################################################################

class Handycipher:

	def __init__(self,key):
		self.corecipher = Corecipher(key)

	def info(self):
		print("Method: Handycipher\n")
		print("Key:    " + self.corecipher.key)
		print("Subkey: " + self.corecipher.keyWithoutNumbers)
		print("")
		print("Key matrix:\n" + self.corecipher.matrixstring)
		print("Forbidden bigrams: " + ' '.join(self.corecipher.bigrams))

	def decode( self, ciphertext, verbose=0 ):

		# remove null characters from the ciphertext
		for null in self.corecipher.nulls:
			ciphertext = ciphertext.replace(null,'')

		result,ofs = self.corecipher.decode( ciphertext, verbose )
		return result

	def encode( self, plaintext, verbose=0 ):
		ciphertext = self.corecipher.encode( plaintext, verbose )
		ciphertext = self.insertNulls( ciphertext )
		return ciphertext


	def insertNulls( self, ciphertext ):

		result = ''

		i = 0
		while 1:
			if random.randint(1,8)<=5:	# with probability 5/8 insert the next ciphertext character
				if i>=len(ciphertext): break
				result += ciphertext[i]
				i += 1
			else: # with probability 3/8 insert a null character
				while 1:
					null = random.choice(self.corecipher.nulls)
					j = result[-1:-6:-1].find(null)
					if not(0<=j<=random.randint(0,4)): break
				result += null

		return result

################################################################################

class Corecipher:

	alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ,.-?^"
	ciphertextalphabet = alphabet + "0123456789"
	powersof2 = [1<<i for i in range(5)]
	exponents = {1<<i: i for i in range(5)}

	def __init__(self,key):
		self.key = key

		self.initkey()
		self.initrelations()
		self.initngrams()

		self.bigrams = [ self.number2char[1<<i]+self.number2char[16>>i] for i in range(5) ]


	def isEncryptable(self, text):
		for bigram in self.bigrams:
			if bigram in text: return False
		return True


	def decode( self, ciphertext, verbose=0, maxlength=-1 ):

		if verbose>2:
			print("Table of sorted homophones:")
			self.printNgrams()
			print("")

		if verbose>1:
			print("Decryption process:")

		plaintext = ''

		ofs=0
		while ofs<len(ciphertext):
			if maxlength>0 and len(plaintext)>=maxlength: break
			parity = (len(plaintext)+1) % 2
			key, token, ofs = self.scantoken(ciphertext,ofs)
			ngram = self.ngrams[parity][key]
			plaintext += ngram['c']
			if verbose>1:
				print('{0}  {1:2}  {1:05b}  {2:3} {3:4}  {4:6}'.format(ngram['c'],ngram['n'],ngram['type']+str(ngram['i']),"odd" if parity else "even",token))

		return (plaintext,ofs)


	def encode( self, plaintext, verbose=0 ):
		return ''.join( self.encodeNgrams(plaintext, verbose ) )


	def encodeNgrams( self, plaintext, verbose=0 ):

		if verbose>2:
			print("Table of sorted homophones:")
			self.printNgrams()
			print("")

		if verbose>1:
			print("Encryption process:")

		ciphertext_ngrams = []

		previous = {'t':'','i':0,'n':0,'c':'','ngram':'','line':''}

		for i in range(len(plaintext)):
			c = plaintext[i]
			parity = (i+1) % 2

			try:
				n = self.char2number[c]
			except KeyError:
				raise Exception("Illegal character '"+c+"' in plaintext at position "+i+".")

			if n*previous['n']==16:
				raise Exception("The plaintext bigram '"+previous['c']+c+"' can not be encrypted.")

			null = ''

			while 1:
				while 1:
					r = random.randint(1,4)

					if r==1: # choose random column with probability 1/4
						t = 'C'
						x = random.randint(0,4)
						s = self.columns[x]

					elif r==2: # choose random row with probability 1/4
						if n in Corecipher.powersof2: continue
						t = 'R'
						x = random.randint(0,4)
						s = self.rows[x]
						# check if selection of row x would lead to infinite loop with next plaintext character
						try:
							if Corecipher.exponents[self.char2number[plaintext[i+1]]]==(x if parity else 4-x):
								continue
						except:
							pass

					else: # choose random diagonal with probability 1/2
						if n in Corecipher.powersof2: continue
						t = 'D'
						x = random.randint(0,9)
						s = self.diagonals[x]
					break

				ngram = Corecipher.filterWithNumber(s,n,parity)
				ngram = Corecipher.shufflestring(ngram)
				line = t+str(x+1)

				# check compatibility with previous encryption step

				if ngram[0] in previous['line']:
					if verbose>3:
						print("WARNING: rejected (condition 3.1): index:{0} line:{1:2} ngram:{2}".format(n,line,ngram))
					continue
				if previous['n'] in Corecipher.powersof2:
					if ngram[0] in self.relations[previous['ngram'][0]]:
						if verbose>3:
							print("WARNING: rejected (condition 3.2): index:{0} line:{1:2} ngram:{2}".format(n,line,ngram))
						continue

				break

			previous = {'t':t,'i':x,'n':n,'c':c,'ngram':ngram,'line':s}

			if verbose>1:
				print('{0}  {1:2}  {1:05b}  {2:3} {3:4}  {4:6}'.format(c,n,line,"odd" if parity else "even",ngram))

			ciphertext_ngrams.append( ngram )

		return ciphertext_ngrams


	def initrelations(self):

		self.relations = {}

		for x in range(5):
			for y in range(5):
				c = self.Matrix[x][y]
				self.relations[c] = set()
				for i in range(5):
					self.relations[c].add(self.Matrix[x][i])
					self.relations[c].add(self.Matrix[i][y])
					self.relations[c].add(self.Matrix[(x+i)%5][(y+i)%5])
					self.relations[c].add(self.Matrix[(x-i)%5][(y+i)%5])


	def initngrams(self):

		self.rows = ['' for x in range(5)]
		self.columns = ['' for x in range(5)]
		self.diagonals = ['' for x in range(10)]

		self.ngrams = [{},{}]
		self.char2ngrams = [{},{}]

		# Get all rows, columns and diagonals as strings
		for x in range(5):
			for y in range(5):
				self.rows[y] += self.Matrix[x][y]
				self.columns[x] += self.Matrix[x][y]
				self.diagonals[x] += self.Matrix[(x+y)%5][y]
				self.diagonals[5+x] += self.Matrix[(x-y)%5][y]

		for n in range(1,32):
			for parity in range(2):
				c = self.number2char[n]

				# Columns
				for i in range(5):
					ngram = Corecipher.sortstring(Corecipher.filterWithNumber(self.columns[i],n,parity))
					self.ngrams[parity][ngram] = {'type':"C",'i':i+1,'n':n,'c':c}

				# Rows
				for i in range(5):
					ngram = Corecipher.sortstring(Corecipher.filterWithNumber(self.rows[i],n,parity))
					if not(ngram in self.ngrams[parity]):
						self.ngrams[parity][ngram] = {'type':"R",'i':i+1,'n':n,'c':c}

				# Diagonals
				for i in range(10):
					ngram = Corecipher.sortstring(Corecipher.filterWithNumber(self.diagonals[i],n,parity))
					if not(ngram in self.ngrams[parity]):
						self.ngrams[parity][ngram] = {'type':"D",'i':i+1,'n':n,'c':c}

		for parity in range(2):
			for k,v in self.ngrams[parity].items():
				c = self.number2char[v['n']]
				if not(c in self.char2ngrams[parity]): self.char2ngrams[parity][c] = []
				self.char2ngrams[parity][c].append(k)

			# Null characters
			for i in range(15):
				self.ngrams[parity][self.nulls[i]] = {'type':"N",'i':i+1,'n':0,'c':''}


	def initkey( self ):

		if self.sortstring(self.key) != self.sortstring(Corecipher.ciphertextalphabet):
			errmsg  = "Given key:          '" + self.key + "'\n"
			errmsg += "Sorted key:         '" + self.sortstring(self.key) + "'\n"
			errmsg += "Regular sorted key: '" + self.sortstring(Corecipher.ciphertextalphabet) + "'"
			raise Exception(errmsg)

		self.keyWithoutSpace = self.key.replace('^', '')
		self.keyWithoutNumbers = re.sub(r'\d', '', self.key)

		self.char2number = {}
		self.number2char = {}
		self.matrixstring = ''

		for x in range(len(self.keyWithoutNumbers)):
			self.char2number[self.keyWithoutNumbers[x]] = x+1
			self.number2char[x+1] = self.keyWithoutNumbers[x]

		self.Matrix = [[0 for x in range(5)] for x in range(5)]
		self.nulls = []

		for y in range(5):
			for x in range(8):
				c = self.keyWithoutSpace[8*y+x]
				if x < 5:
					self.Matrix[x][y] = c
				else:
					self.nulls.append(c)
					if x==5: self.matrixstring += " "
				self.matrixstring += c
			self.matrixstring += "\n"


	def scantoken( self, ciphertext, offset ):

		start = offset
		token = ''

		while offset < len(ciphertext):
			c = ciphertext[offset]
			if c not in Corecipher.ciphertextalphabet:
				print("ERROR: Illegal character '"+c+"' in ciphertext.")
				sys.exit(1)
			if c not in self.nulls:
				newtoken = self.sortstring(token+c)
				if newtoken not in self.ngrams[0]: break
				token = newtoken
			offset += 1

		return (token,ciphertext[start:offset],offset)


	def printNgrams( self ):

		for c in Corecipher.alphabet:
			n = self.char2number[c]
			bits_odd = '{0:05b}'.format(n);
			bits_even = bits_odd[::-1]
			if bits_odd==bits_even:
				print("{0}      {1:2} {2} ".format(c,n,bits_odd)+' '.join(sorted(self.char2ngrams[1][c])))
			else:
				print("{0} odd  {1:2} {2} ".format(c,n,bits_odd)+' '.join(sorted(self.char2ngrams[1][c])))
				print("{0} even {1:2} {2} ".format(c,n,bits_odd)+' '.join(sorted(self.char2ngrams[0][c])))


	@staticmethod
	def randomKey(plaintext=None):
		if plaintext is None:
			return Corecipher.shufflestring(Corecipher.ciphertextalphabet)

		for i in range(0,1000):
			corecipher = Corecipher( Corecipher.randomKey() )
			if corecipher.isEncryptable(plaintext): return corecipher.key

		raise Exception("Could not create a key for the given plaintext.")


	@staticmethod
	def shufflestring( s ):
		l = list(s)
		random.shuffle(l)
		return ''.join(l)


	@staticmethod
	def sortstring( s ):
		return ''.join(sorted(s))


	@staticmethod
	def number2bits( n, parity ):
		bits = [int(i) for i in '{0:05b}'.format(n)]
		if parity==0: bits = bits[::-1]
		return bits


	@staticmethod
	def filterBits( s, bits ):
		result = ''
		for i in range(5):
			if bits[i]: result += s[i]
		return result


	@staticmethod
	def filterWithNumber( s, n, parity ):
		return Corecipher.filterBits( s, Corecipher.number2bits(n,parity) )

################################################################################

def writeTempFile( filename, content ):
	fName, fExtension = os.path.splitext(filename)
	tmpfile = fName + "_tmp" + fExtension
	with open(tmpfile, 'w') as f:
		f.write(content)
	return tmpfile


def deleteIllegalChars( text, allowed ):
	result = ''
	illegalChars = set()

	for c in text:
		if c in allowed:
			result += c
		else:
			illegalChars.add(c)

	return result, illegalChars


def writeoutput( text ):
	if args.output:
		with open(args.output, 'w') as f: f.write(text)
	else:
		print(text)


def replaceOstrokeWithZero( s ):
		s = re.sub('\xd8', '0', s)			# identify � (ISO-8859-1) as zero
		s = re.sub('\x9d', '0', s)			# identify � (IBM850) as zero
		s = re.sub('\xc3\x98', '0', s)	# identify � (UTF-8) as zero
		s = re.sub(u"\u00d8", '0', s)		# identify 'LATIN CAPITAL LETTER O WITH STROKE' (U+00D8) as zero
		return s


testvectors = [
		{
			'key': "ON2TP3FLDSMKY,5ACVER7WIH41UG8.960^?-ZXQJB",
			'ciphertext': "2NTEU2GX1DSOGE4E2MPYKPE?EM-K",
			'plaintext': "CATS AND DOGS",
			'method': "Handycipher"
		},
		{
			'key': "ON2TP3FLDSMKY,5ACVER7WIH41UG8.960^?-ZXQJB",
			'ciphertext': "Z0XBS.IN26S-7.MR60QWTZIR4NB6OM1W5?PNZLFYRXWZPT,FH8UN5BZXCN1HVYGQYCJ-?BK7T?Q1X2EQDISTM6DQKY32UNX.6WTVMOQY52W?KNBO149RNX0F?8DUTMO6SW8G4LNGP-6GC73R1OASU.2EW41OI4P498EK12SFZ7G9LFXK8BVQCJOHSI34HUWKTJZ1679YX2TPO89XQ-Q2UGA8L?UXWQ-FR5CIW.37K5JVRXZQ4V.2LM-P25ZOJSTKZMGJ8EAL.FV71?EDY074KO1MZ8BAXN,VFOQDEIUM2-89U4,P0UW6ITZ3AKUS,ZCPAD,3,O1BF5,XK9XC68VNA412RTBZIM2DPH5QRU,OB16WJ2JM65QES2Y3OZ6X5I024L.PGZ.1-T8?,0LAHSO7J2H0IY9BLOVNZ05X2?QP-1X4P28L16QUND2S9LTWYQ13CJ.,-27I?TXU5,7VR9QK5HBXI8QK6?L39HI4N,ALFCEQ7D-7NVCGKRQZATE7CF,PJKCVOXSBITKND.TRJSO5FXUHS86KQT,JSO720.JLTY4RJ2ZS0PSFXOKYQ-1XI2O1W4PI86EVQ7SPB.QY4198DQ8AG?F6.Y,LIR36X4P87A5O9ZEJ3FCV3MN7BNQLW,HGCA91B-O4DCP?H2YQFZ0A-T-HK432WGATRIZ3L?12MZDU9WJ0?6Z7,RX4F-4AY21DX.N5U?T59IL45-3NID5FREY71TJFA6-8PW.WAF.QJ6W7K6Q0G",
			'plaintext': "IT HAUNTS ME, THE PASSAGE OF TIME. I THINK TIME IS A MERCILESS THING. I THINK LIFE IS A PROCESS OF BURNING ONESELF OUT AND TIME IS THE FIRE THAT BURNS YOU. BUT I THINK THE SPIRIT OF MAN IS A GOOD ADVERSARY.  -- TENNESSEE WILLIAMS",
			'method': "Handycipher"
		},
		{
			'key': "ON2TP3FLDSMKY,5ACVER7WIH41UG8.960^?-ZXQJB",
			'ciphertext': ",CQ8BI46GJMUVAY25WRE.DOCQ1K-S54HV-GEX,P.C-5O8LTM1K?B8.9UGP1X4MJ85HYFP1DC9SPXTI-WN15ZRTFSWEXA-WS1,5AI.QD510R3D,ATZM4Y8,AZ57DUROBQWJDPZRJG6H0SFN?7NMIOD73RF,4SMVJWFRTKE,A17B5INM.?LE7F9EIB1ZMQR.?8HIF3YTSG6?WPF1BX40M67URDEPW.IHX6S38LR-UN9W3M.,N5Z1E7NBPN,S.GWRUWY?CQJK8B6YO1U7EKP50OZ9IADPK,E1OADC9MK.H6MP2OHV,3C?8VM682NY4VHKL50156PJ2U9EGZQN057XCQEFU6ZWNCR6AUV1J89?7UMCPY6WTF0?P.TDONRVT.7-YK041Y3P.OS6UPFR?W5GR9862KE.WFRHICJ-PQ1ZNKCT4E7BM98UTGLXY9M7K1BPG7WX?L71BJ95AU?HCSF4QS1J-.U0?KD4HUBOM9TKIFQ5SMA,CL2.YQSTZX5I0KPGE?LYT,7XNVIJ82SACLNXUK98B2M4I26B?.QRAS8Z-KLEVSFHYL92JZ?T80.?AY-5XW.938ZO?R4K.JS25HOX63G7X.CNMTOZ7,PXI?NC06H7DVF6ARKSXYGT9RJ6XA4QHVHKSML7I8UTPSKB23WFN6YEOG71,?.IZTG4EUXDB-GF.DMZUECX,R420RUNDQX.2,1.9XTJB?8MUVA,3.JSWUI4YSV.8TI?WRL6IBD9V.ZCMFN4G7-.?B9?X0ZWQYC5TLS8JZC23160HG0.MN5UIXKQPCJZVS5?9CRL7OT5,A24LFMTBV2KXA23QU,HI-SZ.JCN7OHFYNSPT?MWJP459?T1.YCUP?9F,4NE6C71GN8W9MG6BSO14P37,U2-5Q4.UG1OZ.WGHLC9VG5W814T?W9N5X1-NVS?G.5-VXBA.NH5X0-648HBDPMEYPH34RPWE1BMEU50AYTSY-70BF5TZ10ST-YJ.NH52OHL8ZGN-QJYI48HGUW,SFMKJVSPTS0VBX49MQZQ1XA8TFKHNBMOG2VBCUVIFZ.Y5ZAXF9U6B?.QE7W9I5LZ3T.02LX4EAQZ24HUTV95RJZKPSVWCB1ZY8XV3?U.8FHJ7BSEU?IWS3.Q0ZPO,548,UDAP9GTDQWEK0-CHJK-MLT6P0XC4LUZW-4DWORP67L,CMKJ16VZC04,LQ1O3,ME5WHQFUYN?.VQKN3LZIO?C9?PNFG?OMKN1VB624TK,ITRO.4J9,ZOIM6QHXB0WJRAV0AQ7S8B2W1IXO3BHQ?DXNLHM.KOU?U05N6BGUONKRXGYI4T8HV-E8OP?KS2FA9KSGQXZ8CUIO7UAE7Q6H.8MTD3VPBO0F38E2VG-",
			'plaintext': "IT HAUNTS ME, THE PASSAGE OF TIME. I THINK TIME IS A MERCILESS THING. I THINK LIFE IS A PROCESS OF BURNING ONESELF OUT AND TIME IS THE FIRE THAT BURNS YOU. BUT I THINK THE SPIRIT OF MAN IS A GOOD ADVERSARY.  -- TENNESSEE WILLIAMS",
			'method': "Extended HC"
		}
]

ciphertext = ''
plaintext = ''
errmsg = ''
modmessage = ''

parser = argparse.ArgumentParser(prog='Handycipher')

parser.add_argument("-V", "--version", action='version', version='%(prog)s '+version)
parser.add_argument("-v", "--verbose", help="turn on multiple levels of verbosity", action="count", default=0)
parser.add_argument("-x", "--extended", help="use Extended Handycipher instead of Handycipher", action="store_true")
parser.add_argument("-e", "--encrypt", metavar="FILE", help="read plaintext from FILE and encrypt it")
parser.add_argument("-d", "--decrypt", metavar="FILE", help="read ciphertext from FILE and decrypt it")
parser.add_argument("-k", "--keyfile", metavar="FILE", help="read key from FILE")
parser.add_argument("-n", "--nobigrams", metavar="FILE", help="encrypt plaintext with a generated key, for which the plaintext contains no forbidden bigrams, and save the key in FILE (Handycipher only)")
parser.add_argument("-g", "--generate", help="generate a random key and print it to stdout", action="store_true")
parser.add_argument("-o", "--output", metavar="FILE", help="save output (plaintext, ciphertext or key) to FILE")
parser.add_argument("-t", "--test", help="decrypt a test ciphertext", choices=[1,2,3], type=int)
args = parser.parse_args()

if len(sys.argv)==1:
	parser.print_help()
	sys.exit(1)

if args.generate:
	writeoutput(Corecipher.randomKey())
	sys.exit(1)

if args.extended:
	method = 'Extended HC'
else:
	method = 'Handycipher'

if args.test:
	key = testvectors[args.test-1]['key']
	ciphertext = testvectors[args.test-1]['ciphertext']
	mode = 'decrypt'
	method = testvectors[args.test-1]['method']
else:
	if args.keyfile:
		key = open(args.keyfile, 'r').read().rstrip('\r\n')
		key = key.replace(' ', '^')	# replace space with ^
		key = replaceOstrokeWithZero( key )

	if args.decrypt:
		ciphertext0 = open(args.decrypt, 'r').read().rstrip('\r\n')
		ciphertext = ciphertext0
		ciphertext = ciphertext.upper()
		ciphertext = re.sub(r'\s+', '', ciphertext)	# delete all whitespaces
		ciphertext = replaceOstrokeWithZero( ciphertext )
		if ciphertext != ciphertext0:
			tmpfile = writeTempFile(args.decrypt, ciphertext)
			modmessage = "\nThe modified ciphertext was written to the file '"+tmpfile+"'."
		mode = 'decrypt'

	if args.encrypt:
		plaintext0 = open(args.encrypt, 'r').read().rstrip('\r\n')
		plaintext = plaintext0
		plaintext = plaintext.replace(' ', '^')	# replace spaces with ^
		plaintext = re.sub(r'\s+', '', plaintext)	# delete all other whitespaces
		plaintext = plaintext.upper()

		plaintext, illegalChars = deleteIllegalChars( plaintext, Corecipher.alphabet )

		if plaintext != plaintext0:
			tmpfile = writeTempFile(args.encrypt, plaintext)
			modmessage = "\nThe modified plaintext was written to the file '"+tmpfile+"'."
		if args.nobigrams and method=='Handycipher':
			key = Corecipher.randomKey(plaintext)
			with open(args.nobigrams, 'w') as f: f.write(key)
		mode = 'encrypt'

try:
	key
except NameError:
	print("ERROR: key not defined")
	sys.exit(1)

try:
	if method=='Handycipher':
		cipher = Handycipher(key)
	else:
		cipher = ExtendedHandycipher(key)
except Exception as e:
	print("ERROR: The given key is not valid.\n\n" + e.args[0])
	sys.exit(1)

try:
	if mode=='encrypt':
		ciphertext = cipher.encode(plaintext, args.verbose)
		result = ciphertext

	if mode=='decrypt':
		plaintext = cipher.decode(ciphertext, args.verbose)
		plaintext = plaintext.replace('^', ' ')		# replace ^ with spaces
		result = plaintext
except Exception as e:
	errmsg = e.args[0]

if args.verbose>0:
	print("")
	print("Ciphertext: " + ciphertext + "\n")
	if mode=='encrypt' and plaintext != plaintext0:
		print("Modified plaintext: " + plaintext + "\n")
	else:
		print("Plaintext: " + plaintext + "\n")
	print("Ciphertext length: " + str(len(ciphertext)) + " characters")
	print("Plaintext length: " + str(len(plaintext)) + " characters")
	print("")
	cipher.info()
	if modmessage!='': print(modmessage)

	try:
		if illegalChars:
			print("\nThe plaintext may only contain the following characters:  [" + Corecipher.alphabet + " ]")
			try:
				s = "\nThese illegal characters were deleted from the plaintext: [" + ''.join(sorted(illegalChars)) + "]"
				print(s.decode("utf-8", errors="ignore"))
			except:
				print("\nSome illegal characters were deleted from the plaintext.")
	except:
		pass

	print("")

if errmsg:
	print("ERROR: "+errmsg)
	sys.exit(1)

writeoutput(result)

sys.exit(0)
